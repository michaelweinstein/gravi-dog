package miweinst.engine.entityIO;

import java.util.Map;

public abstract class Input {	
	public abstract void run(Map<String, String> args);
}
